﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bob's Big Giveaway");
            Console.Write("Choose a door: 1, 2 or 3: ");
            string userValue = Console.ReadLine();

            string msg = (userValue == "1") ? "boat" : "strand of lint";

            Console.WriteLine("You entered: {0}, therefore you won a {1}.", userValue, msg);
            Console.ReadLine();

        }
    }
}

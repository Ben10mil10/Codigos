﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2
{
    internal class Program
    {
        static void Main(string[] args)
        {
          

            Console.WriteLine("What's your name? ");
            Console.Write("Type your first name: ");
            string PrimerNombre;
            PrimerNombre = Console.ReadLine();

            

            Console.Write("Type your last name: ");
            string PrimerApellido = Console.ReadLine();

            Console.WriteLine("Hello, " + PrimerNombre + " " + PrimerApellido);
            Console.ReadLine();
        }
    }
}
